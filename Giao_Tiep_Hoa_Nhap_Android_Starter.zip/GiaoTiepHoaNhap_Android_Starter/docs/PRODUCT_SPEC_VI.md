# Đặc tả sản phẩm — Giao Tiếp Hòa Nhập

## 1. Người dùng và các luồng chính
### A. Người điếc/khiếm thính biết chữ
1. Nhấn “Nghe người đối diện”.
2. App nhận dạng tiếng Việt và hiển thị câu chữ lớn.
3. Người dùng có thể sửa câu nhận dạng sai.
4. Người dùng trả lời bằng cách gõ hoặc chọn câu mẫu.
5. App đọc câu trả lời thành tiếng qua TTS.

### B. Người điếc/khiếm thính không đọc chữ thành thạo
1. Người đối diện nói; hệ thống nhận dạng tiếng Việt.
2. App chuyển câu sang chuỗi nội dung ký hiệu đã được chuyên gia ngôn ngữ ký hiệu xác thực.
3. Hiển thị clip ký hiệu/hoạt ảnh ký hiệu theo từng cụm, kèm nút phát lại/chậm lại.
4. Người dùng phản hồi bằng cách chọn thẻ hình minh họa hoặc thư viện câu có ký hiệu.
5. App phát giọng nói tương ứng cho người đối diện.

**Điều kiện bắt buộc:** bước 2 không thể được giải quyết đáng tin cậy bằng cách đổi từng từ thành hình bàn tay. Cần bộ dữ liệu ngôn ngữ ký hiệu có bản quyền/được cho phép, chuyên gia người Điếc tham gia xác thực, xử lý ngữ pháp và phương án cho từ chưa có ký hiệu.

### C. Người dùng muốn nói thay bằng giọng máy
1. Gõ câu hoặc chọn câu nhanh.
2. Chọn giọng khả dụng trên thiết bị/dịch vụ TTS.
3. Chọn tốc độ, cao độ và âm lượng; sắc thái cảm xúc chỉ hiện khi engine hỗ trợ.
4. Nhấn “Phát giọng nói”.

## 2. Màn hình đề xuất
- Màn hình chính: hai nút lớn “Nghe người đối diện” và “Tôi muốn trả lời”.
- Màn hình chữ lớn: tương phản cao, cỡ chữ tùy chỉnh, lịch sử hội thoại, sửa kết quả nhận dạng.
- Màn hình ký hiệu: video/hoạt ảnh, phát lại, tốc độ 0.5×/0.75×/1×, câu theo ngữ cảnh.
- Màn hình tạo giọng nói: nhập văn bản, câu nhanh, chọn giọng, tốc độ/cao độ.
- Cài đặt hỗ trợ: biết chữ/chủ yếu dùng hình; cỡ chữ; tương phản; rung; âm lượng; ngôn ngữ; quyền riêng tư.
- Chế độ ngoại tuyến: chỉ các câu mẫu và nội dung đã tải xuống; nhận dạng giọng nói có thể không hoạt động.

## 3. Nguyên tắc thiết kế tiếp cận
- Không dựa hoàn toàn vào màu sắc hoặc âm thanh để báo trạng thái.
- Nút lớn, nhãn ngắn, biểu tượng kèm chữ/hình minh họa.
- Cho phép hủy, sửa và phát lại.
- Không tự động gửi nội dung nhận dạng cho người khác.
- Có hướng dẫn bằng hình/video, không yêu cầu người dùng đọc hướng dẫn dài.
- Kiểm thử với người Điếc/khiếm thính thực tế ở nhiều độ tuổi và trình độ đọc khác nhau.

## 4. Kiến trúc đề xuất
- Ứng dụng: Android native hoặc Flutter/React Native.
- Speech-to-text: engine thiết bị hoặc nhà cung cấp STT tiếng Việt; cần đánh giá độ chính xác trong môi trường ồn.
- TTS: engine hệ điều hành hoặc nhà cung cấp có hỗ trợ giọng tiếng Việt; cảm xúc/SSML tùy nhà cung cấp.
- Dịch sang ngôn ngữ ký hiệu: bộ máy ánh xạ ngữ nghĩa/câu sang thư viện video ký hiệu đã xác thực; không chỉ ánh xạ từ đơn.
- Lưu trữ: ưu tiên xử lý trên thiết bị; nếu dùng máy chủ thì mã hóa truyền tải, giới hạn lưu log, chính sách xóa dữ liệu rõ ràng.
- Quản trị nội dung: công cụ cập nhật câu mẫu và video ký hiệu, có quy trình kiểm duyệt.

## 5. Rủi ro và cách giảm thiểu
- Nhận dạng sai trong môi trường ồn: hiển thị trạng thái tin cậy nếu engine cung cấp; cho sửa trước khi đọc/phát.
- Ký hiệu sai ngữ cảnh: chuyên gia người Điếc duyệt nội dung; cho phép xem câu gốc và yêu cầu xác nhận.
- Khác biệt vùng miền: ghi rõ vùng/ngôn ngữ ký hiệu được hỗ trợ và kiểm thử tại địa phương.
- Quyền riêng tư: thông báo rõ khi âm thanh được gửi lên dịch vụ đám mây; không lưu âm thanh mặc định.
- Tình huống quan trọng: cảnh báo người dùng xác nhận thông tin quan trọng bằng phương pháp thứ hai.

## 6. Phạm vi MVP khả thi
MVP 1:
- Nhận dạng tiếng Việt → chữ lớn.
- Gõ/chọn câu → phát giọng nói.
- Chọn các giọng được thiết bị hỗ trợ.
- Câu giao tiếp nhanh, lịch sử phiên hiện tại, cỡ chữ/tương phản.
- Demo luồng ký hiệu nhưng chưa tuyên bố phiên dịch thật cho đến khi có dữ liệu ký hiệu được kiểm duyệt.

MVP 2:
- Thêm thư viện video ký hiệu tiếng Việt theo nhóm chủ đề, được cộng đồng người Điếc và chuyên gia duyệt.
- Tối ưu offline, lưu câu yêu thích, chế độ một chạm.
- Thử nghiệm thực địa và đánh giá hiểu đúng/sai.

## 7. Tiêu chí nghiệm thu tối thiểu
- Không phát âm thanh khi chưa có hành động của người dùng, trừ khi bật rõ ràng.
- Người dùng có thể dừng phát âm ngay lập tức.
- Kết quả STT có thể sửa trước khi đọc.
- Chế độ chữ lớn hoạt động trên màn hình nhỏ.
- Không lưu âm thanh/văn bản nhạy cảm mặc định.
- Mọi clip ký hiệu có nguồn, quyền sử dụng và người duyệt.
- Kiểm thử với người Điếc/khiếm thính; ghi nhận tỷ lệ hiểu đúng, không chỉ kiểm thử kỹ thuật.
