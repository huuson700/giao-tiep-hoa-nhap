# Checklist bàn giao cho đơn vị phát triển

## Những gì có trong gói
- `app/index.html`: demo trình duyệt một tệp, giao diện tiếng Việt.
- `docs/PRODUCT_SPEC_VI.md`: yêu cầu sản phẩm và kiến trúc đề xuất.
- `docs/HANDOFF_CHECKLIST_VI.md`: checklist bàn giao/kiểm thử.

## Các việc đơn vị phát triển phải hoàn tất
- [ ] Chốt nền tảng: Android, iOS hay PWA.
- [ ] Chốt phạm vi ngôn ngữ ký hiệu (ví dụ khu vực/ngữ hệ cụ thể) cùng cộng đồng người Điếc.
- [ ] Chọn STT/TTS, kiểm tra hỗ trợ tiếng Việt, chi phí, chính sách dữ liệu và khả năng chạy offline.
- [ ] Thiết lập tài khoản, API key/secret ở máy chủ (không nhúng khóa bí mật vào ứng dụng).
- [ ] Thu thập/được cấp quyền sử dụng video ký hiệu; chuyên gia người Điếc duyệt.
- [ ] Xây dựng API an toàn, giới hạn lưu dữ liệu và xóa dữ liệu.
- [ ] Kiểm thử thiết bị thật, môi trường ồn, giọng địa phương, người dùng ít biết chữ.
- [ ] Kiểm thử bảo mật, khả năng tiếp cận, hiệu năng và xử lý khi mất mạng.
- [ ] Ký phát hành, cấu hình cửa hàng ứng dụng hoặc hosting HTTPS.
- [ ] Bàn giao mã nguồn, hướng dẫn build/release, sơ đồ kiến trúc, danh sách dịch vụ và chi phí vận hành.

## Điều không thể cam kết trung thực
Không thể bảo đảm một gói phần mềm cần dịch vụ STT/TTS và dữ liệu ký hiệu có thể hoạt động đầy đủ “không cần cài đặt hay hiệu chỉnh” trên mọi điện thoại. Tối thiểu vẫn cần chọn nền tảng, quyền micro, hosting hoặc build ứng dụng, và cấu hình dịch vụ bên ngoài.
