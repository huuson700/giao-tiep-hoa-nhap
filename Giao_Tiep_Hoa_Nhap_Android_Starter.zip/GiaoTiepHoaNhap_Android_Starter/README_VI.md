# Giao Tiếp Hòa Nhập — Android Starter (MVP A)

## Có gì trong gói?
- Dự án Android Gradle cơ bản bọc `app/src/main/assets/index.html` trong Android WebView.
- Demo có giao diện tiếng Việt, nhập văn bản và đọc thành tiếng bằng engine TTS của trình duyệt/thiết bị, câu nhanh, chữ lớn/tương phản cao.
- Workflow GitHub Actions để thử biên dịch APK debug trực tuyến.

## Hạn chế — đọc trước khi dùng
- Đây là starter để thử nghiệm, không phải bản phát hành thương mại đã kiểm thử.
- Nhận dạng giọng nói trong WebView có thể không hoạt động trên mọi máy/phiên bản Android. TTS phụ thuộc giọng hệ thống.
- Chưa có dịch sang ngôn ngữ ký hiệu thực tế, chưa có xử lý ngoại tuyến hoàn chỉnh, chưa có giọng cảm xúc được bảo đảm.
- APK debug do workflow tạo ra chỉ dành cho thử nghiệm; không phải APK release đã ký để phát hành cửa hàng.
- Cần Internet/GitHub account để biên dịch trực tuyến. Không có cách trung thực nào bảo đảm “không cấu hình gì” khi tạo ứng dụng Android từ mã nguồn.

## Tạo APK trên điện thoại bằng GitHub Actions
1. Tạo tài khoản GitHub nếu chưa có.
2. Trên GitHub, tạo repository mới, ví dụ `giao-tiep-hoa-nhap`; đặt Public nếu muốn dùng Actions miễn phí dễ hơn. Không đưa dữ liệu cá nhân hoặc khóa bí mật vào repository.
3. Tải ZIP này xuống, giải nén trên điện thoại bằng ứng dụng quản lý tệp.
4. Tải từng tệp/thư mục lên repository giữ nguyên cấu trúc. GitHub trên trình duyệt di động có thể khó tải cả thư mục; có thể cần GitHub mobile app hoặc dịch vụ upload repo. Nếu giao diện không cho tải thư mục, đừng đổi tên hoặc bỏ các thư mục `.github/workflows`.
5. Mở tab Actions của repository, chọn “Build Android APK”, nhấn “Run workflow”.
6. Khi workflow hoàn tất, mở lần chạy đó, kéo xuống Artifacts và tải `GiaoTiepHoaNhap-debug-apk`.
7. Giải nén artifact để lấy `app-debug.apk`, rồi mở trên điện thoại và cho phép cài ứng dụng từ nguồn đó nếu anh tin tưởng chính repository của mình.

## Cấu hình build
- Android Gradle Plugin 8.7.3
- JDK 17
- compileSdk 35
- minSdk 23
- Package ID: `vn.hoanhap.giaotiep`

## Ghi chú kỹ thuật
Workflow dùng lệnh `gradle assembleDebug` do runner GitHub có Gradle. Nếu runner thay đổi và build thất bại, xem log trong Actions; cần sửa workflow tương ứng. Luôn thử trên máy phụ trước khi dùng thường xuyên.
